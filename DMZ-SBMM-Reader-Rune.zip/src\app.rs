﻿use crate::model::now_local_hms;
use crate::probe::Probe;
use crate::scanner::{ScanOptions, default_keywords, detect_cod_paths, scan};
use rune::tok::{self, radius, space, type_};
use rune::{Cx, El, ScrollSpec, TextEdit, col, el, row, text, text_input};
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::thread::{self, JoinHandle};
use std::time::Duration;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Tab {
    Scan,
    Probe,
}

pub struct State {
    pub tab: Tab,
    pub dark: bool,
    // scan
    pub paths_edit: TextEdit,
    pub max_mb: u64,
    pub no_size_limit: bool,
    pub skip_binary: bool,
    pub scan_status: String,
    pub scan_log: Vec<String>,
    pub scan_report: Option<PathBuf>,
    pub scan_json: Option<PathBuf>,
    pub scanning: bool,
    pub scan_result: Arc<Mutex<Option<Result<crate::model::ScanResult, String>>>>,
    // probe
    pub probe: Option<Arc<Mutex<Probe>>>,
    pub probe_status: String,
    pub probe_log: Vec<String>,
    pub probe_done: bool,
    // background read-only network sampler (5s interval)
    pub net_sampler_stop: Arc<AtomicBool>,
    pub net_sampler_thread: Option<JoinHandle<()>>,
}

impl Default for State {
    fn default() -> Self {
        let paths = detect_cod_paths();
        let paths_text = if paths.is_empty() {
            String::new()
        } else {
            paths.iter().map(|p| p.display().to_string()).collect::<Vec<_>>().join("\n")
        };
        let mut s = Self {
            tab: Tab::Scan,
            dark: true,
            paths_edit: TextEdit::new(&paths_text),
            max_mb: 32,
            no_size_limit: false,
            skip_binary: false,
            scan_status: "Ready.".to_string(),
            scan_log: vec!["DMZ SBMM Reader (Rust/Rune) started. Read-only.".to_string()],
            scan_report: None,
            scan_json: None,
            scanning: false,
            scan_result: Arc::new(Mutex::new(None)),
            probe: None,
            probe_status: "Match 1   |   Queue: not started".to_string(),
            probe_log: vec!["Match probe ready. Read-only metadata only.".to_string()],
            probe_done: false,
            net_sampler_stop: Arc::new(AtomicBool::new(false)),
            net_sampler_thread: None,
        };
        s.ensure_probe();
        s.update_probe_status();
        s
    }
}

impl State {
    fn out_dir() -> PathBuf {
        std::env::current_exe()
            .ok()
            .and_then(|p| p.parent().map(|d| d.to_path_buf()))
            .unwrap_or_else(|| std::env::current_dir().unwrap_or_else(|_| PathBuf::from(".")))
    }

    fn ensure_probe(&mut self) {
        if self.probe.is_some() { return; }
        let out = Self::out_dir();
        let scan_paths = detect_cod_paths();
        let probe = Probe::new(out, scan_paths);
        let _ = probe.init_files();
        probe.log("DMZ SBMM Match Probe started (read-only).");
        self.probe = Some(Arc::new(Mutex::new(probe)));
        self.start_net_sampler();
    }

    // Lock helpers: UI handlers never hold a probe lock across a thread join.
    fn probe_mut<R>(&self, f: impl FnOnce(&mut Probe) -> R) -> Result<R, String> {
        let guard = self.probe.as_ref().ok_or("Probe not initialized")?;
        let mut p = guard.lock().map_err(|_| "Probe lock poisoned".to_string())?;
        Ok(f(&mut p))
    }

    fn probe_ref<R>(&self, f: impl FnOnce(&Probe) -> R) -> Result<R, String> {
        let guard = self.probe.as_ref().ok_or("Probe not initialized")?;
        let p = guard.lock().map_err(|_| "Probe lock poisoned".to_string())?;
        Ok(f(&p))
    }

    // 5-second background sampler: read-only TCP connection metadata, matching
    // the original PowerShell toolkit's behaviour. Runs until "Stop & report".
    fn start_net_sampler(&mut self) {
        if self.net_sampler_thread.is_some() { return; }
        let Some(probe) = self.probe.clone() else { return; };
        self.net_sampler_stop.store(false, Ordering::Relaxed);
        let stop = self.net_sampler_stop.clone();
        self.net_sampler_thread = Some(thread::spawn(move || loop {
            if stop.load(Ordering::Relaxed) { break; }
            match probe.lock() {
                Ok(p) => {
                    if let Err(e) = p.sample_network() {
                        p.log(&format!("Network sample error: {e}"));
                    }
                }
                Err(_) => break,
            }
            // Sleep in short slices so "Stop & report" is responsive.
            for _ in 0..50 {
                if stop.load(Ordering::Relaxed) { return; }
                thread::sleep(Duration::from_millis(100));
            }
        }));
        self.push_probe_log("Network watch started (5s interval, read-only).");
        let _ = self.probe_ref(|p| p.log("Network watch started (5s interval, read-only)."));
    }

    fn stop_net_sampler(&mut self) {
        if self.net_sampler_thread.is_none() { return; }
        self.net_sampler_stop.store(true, Ordering::Relaxed);
        if let Some(handle) = self.net_sampler_thread.take() {
            let _ = handle.join();
        }
        self.push_probe_log("Network watch stopped.");
        let _ = self.probe_ref(|p| p.log("Network watch stopped."));
    }

    fn push_scan_log(&mut self, msg: impl Into<String>) {
        let line = format!("{}  {}", now_local_hms(), msg.into());
        self.scan_log.push(line);
        if self.scan_log.len() > 500 { let drain = self.scan_log.len() - 500; self.scan_log.drain(0..drain); }
    }
    fn push_probe_log(&mut self, msg: impl Into<String>) {
        let line = format!("{}  {}", now_local_hms(), msg.into());
        self.probe_log.push(line);
        if self.probe_log.len() > 500 { let drain = self.probe_log.len() - 500; self.probe_log.drain(0..drain); }
    }

    fn update_probe_status(&mut self) {
        let info = self.probe_ref(|p| (p.match_number, p.queue_start.is_some()));
        if let Ok((n, started)) = info {
            let q = if started { "started" } else { "not started" };
            let watch = if self.net_sampler_thread.is_some() { "ON" } else { "OFF" };
            self.probe_status = format!("Match {n}   |   Queue: {q}   |   Net watch: {watch}");
        }
    }
}

pub fn view(s: &State, cx: &mut Cx<State>) -> El {
    let t = tok::theme(s.dark);
    let bg = t.bg;
    let card = t.card;
    let border = t.card_border;
    let textc = t.text;
    // MW4-inspired tactical lime accent.
    let mw4 = rune::oklch(0.82, 0.21, 128.0);
    let accent = mw4;
    let ci = cx.chrome_insets();
    let header_h = (ci.height.max(44.0)) + 10.0;

    let header = row()
        .key("header")
        .w_full()
        .h(header_h)
        .pl(space::S6 + ci.leading)
        .pr(space::S6 + ci.trailing)
        .center_y()
        .justify_between()
        .window_drag()
        .child(
            text("DMZ SBMM Reader")
                .key("title")
                .font(type_::TITLE)
                .color(textc),
        )
        .child(
            row()
                .key("tabs")
                .gap(space::S2)
                .child(tab_button("tab-scan", "File scan", s.tab == Tab::Scan, accent, card, border, textc, |st: &mut State| st.tab = Tab::Scan))
                .child(tab_button("tab-probe", "Match probe", s.tab == Tab::Probe, accent, card, border, textc, |st: &mut State| st.tab = Tab::Probe)),
        );

    let body = match s.tab {
        Tab::Scan => scan_view(s, t, accent),
        Tab::Probe => probe_view(s, t, accent),
    };

    col()
        .key("root")
        .w_full()
        .h_full()
        .fill(bg)
        .border(2.0, mw4.alpha(0.9))
        .child(header)
        .child(
            el()
                .key("body-wrap")
                .w_full()
                .grow(1.0)
                .min_h(0.0)
                .px(space::S6)
                .pb(space::S6)
                .pt(space::S3)
                .child(body),
        )
}

#[allow(clippy::too_many_arguments)]
fn tab_button(key: &'static str, label: &'static str, active: bool, accent: rune::Color, card: rune::Color, border: rune::Color, textc: rune::Color, on: fn(&mut State)) -> El {
    el().key(key).h(30.0).px(space::S3).center().radius(radius::MD)
        .fill(if active { accent } else { card })
        .border(1.0, if active { accent } else { border })
        .on_press(on)
        .child(text(label).font(type_::LABEL).color(if active { rune::oklch(0.18, 0.0, 0.0) } else { textc }))
}

fn btn(key: &str, label: &str, bg: rune::Color, fg: rune::Color, on: impl Fn(&mut State) + 'static) -> El {
    el().key(key.to_string()).h(34.0).px(space::S3).center().radius(radius::MD).fill(bg)
        .on_press(on)
        .child(text(label.to_string()).font(type_::LABEL).color(fg))
}

fn scan_view(s: &State, t: tok::Theme, accent: rune::Color) -> El {
    let muted = t.text_secondary;
    let textc = t.text;
    let panel = t.card;
    let border = t.card_border;

    let paths_box = col().key("paths").gap(space::S1)
        .child(text("Folders to scan (one per line):").font(type_::LABEL).color(muted))
        .child(el().key("paths-field").w_full().h(80.0).px(space::S2).py(space::S2).radius(radius::MD).fill(panel).border(1.0, border)
            .child(text_input(&s.paths_edit, type_::BODY).key("paths-input").w_full().color(textc).on_edit(|st: &mut State| &mut st.paths_edit)));

    let controls = row().key("scan-controls").gap(space::S2).center_y()
        .child(toggle_btn("skip-bin", "Skip binary", s.skip_binary, accent, panel, border, textc, |st| st.skip_binary = !st.skip_binary))
        .child(toggle_btn("no-limit", "No size limit", s.no_size_limit, accent, panel, border, textc, |st| st.no_size_limit = !st.no_size_limit))
        .child(btn("scan-now", "Scan now", accent, rune::oklch(0.18, 0.0, 0.0), |st: &mut State| do_scan(st)))
        .child(btn("scan-detect", "Detect paths", panel, textc, |st: &mut State| {
            let p = detect_cod_paths();
            let txt = p.iter().map(|x| x.display().to_string()).collect::<Vec<_>>().join("\n");
            st.paths_edit = TextEdit::new(&txt);
            st.push_scan_log(format!("Detected {} path(s)", p.len()));
        }))
        .child(btn("scan-zip", "Export ZIP...", panel, textc, |st: &mut State| export_scan_zip(st)));

    let status = text(s.scan_status.clone()).key("scan-status").font(type_::BODY).color(muted);

    let log_text = if s.scan_log.is_empty() { "No log.".to_string() } else { s.scan_log.iter().rev().take(80).cloned().collect::<Vec<_>>().into_iter().rev().collect::<Vec<_>>().join("\n") };
    let log_box = col().key("scan-log").w_full().grow(1.0).min_h(120.0).gap(space::S1)
        .child(text("Log / results:").font(type_::LABEL).color(muted))
        .child(el().key("scan-log-box").w_full().grow(1.0).min_h(0.0).px(space::S2).py(space::S2).radius(radius::MD).fill(panel).border(1.0, border)
            .scroll(ScrollSpec { stick_bottom: false })
            .child(text(log_text).key("scan-log-text").font(type_::MONO_CAPTION).color(textc)));

    col().key("scan").w_full().h_full().gap(space::S3)
        .child(text("Search local Call of Duty files for SBMM-related strings (read-only).").font(type_::BODY).color(textc))
        .child(paths_box)
        .child(controls)
        .child(status)
        .child(log_box)
        .child(text("Read-only. Nothing is written into game folders. No matches does not prove SBMM is absent.").font(type_::LABEL).color(muted))
}

fn probe_view(s: &State, t: tok::Theme, accent: rune::Color) -> El {
    let muted = t.text_secondary;
    let textc = t.text;
    let panel = t.card;
    let border = t.card_border;
    let green = rune::oklch(0.62, 0.16, 145.0);
    let yellow = rune::oklch(0.78, 0.14, 85.0);
    let red = rune::oklch(0.58, 0.18, 25.0);
    let blue = rune::oklch(0.62, 0.14, 250.0);

    let status = text(s.probe_status.clone()).key("probe-status").font(type_::TITLE).color(accent);

    let controls = row().key("probe-controls").gap(space::S2)
        .child(btn("qstart", "1. Queue started", green, rune::oklch(0.12,0.0,0.0), probe_queue_start))
        .child(btn("qend", "2. Match found", blue, rune::oklch(0.98,0.0,0.0), probe_queue_end))
        .child(btn("mend", "3. Match ended", yellow, rune::oklch(0.15,0.0,0.0), probe_match_end))
        .child(btn("pstop", "Stop & report", red, rune::oklch(0.98,0.0,0.0), probe_stop))
        .child(btn("pzip", "Export ZIP...", panel, textc, export_probe_zip));

    let log_text = if s.probe_log.is_empty() { "No log.".to_string() } else { s.probe_log.iter().rev().take(120).cloned().collect::<Vec<_>>().into_iter().rev().collect::<Vec<_>>().join("\n") };
    let log_box = col().key("probe-log").w_full().grow(1.0).min_h(120.0).gap(space::S1)
        .child(text("Activity log:").font(type_::LABEL).color(muted))
        .child(el().key("probe-log-box").w_full().grow(1.0).min_h(0.0).px(space::S2).py(space::S2).radius(radius::MD).fill(panel).border(1.0, border)
            .scroll(ScrollSpec { stick_bottom: false })
            .child(text(log_text).key("probe-log-text").font(type_::MONO_CAPTION).color(textc)));

    col().key("probe").w_full().h_full().gap(space::S3)
        .child(text("Track several matches. Read-only process/network/file metadata only.").font(type_::BODY).color(textc))
        .child(status)
        .child(controls)
        .child(log_box)
        .child(text("No injection, no memory reads, no network interception, no writes into game folders.").font(type_::LABEL).color(muted))
}

#[allow(clippy::too_many_arguments)]
fn toggle_btn(key: &str, label: &str, on: bool, accent: rune::Color, panel: rune::Color, border: rune::Color, textc: rune::Color, f: fn(&mut State)) -> El {
    el().key(key.to_string()).h(34.0).px(space::S3).center().radius(radius::MD)
        .fill(if on { accent } else { panel })
        .border(1.0, if on { accent } else { border })
        .on_press(f)
        .child(text(label.to_string()).font(type_::LABEL).color(if on { rune::oklch(0.18,0.0,0.0) } else { textc }))
}

fn do_scan(st: &mut State) {
    if st.scanning { return; }
    let raw = st.paths_edit.text.to_string();
    let paths: Vec<PathBuf> = raw.lines().map(|l| l.trim()).filter(|l| !l.is_empty()).map(PathBuf::from).collect();
    if paths.is_empty() {
        st.scan_status = "Add at least one folder.".to_string();
        st.push_scan_log("No paths provided.");
        return;
    }
    st.scanning = true;
    st.scan_status = "Scanning...".to_string();
    st.push_scan_log(format!("Scan started ({} path(s))", paths.len()));

    let out_dir = State::out_dir();
    let opts = ScanOptions {
        paths,
        output: out_dir.join("DMZ_SBMM_Reader_result.txt"),
        json_output: Some(out_dir.join("DMZ_SBMM_Reader_result.json")),
        zip_output: None,
        max_file_mb: st.max_mb,
        no_size_limit: st.no_size_limit,
        skip_binary: st.skip_binary,
        keywords: default_keywords(),
    };

    // Synchronous for reliability in this rewrite; UI blocks during scan like simple tools do.
    match scan(&opts) {
        Ok(r) => {
            st.scan_status = format!("Finished: scanned {} | skipped {} | errors {} | hits {}", r.summary.scanned, r.summary.skipped, r.summary.errors, r.summary.hits);
            st.push_scan_log(st.scan_status.clone());
            st.scan_report = Some(PathBuf::from(&r.output));
            st.scan_json = r.json_output.as_ref().map(PathBuf::from);
        }
        Err(e) => {
            st.scan_status = format!("Scan error: {e}");
            st.push_scan_log(st.scan_status.clone());
        }
    }
    st.scanning = false;
}

fn export_scan_zip(st: &mut State) {
    let Some(report) = st.scan_report.clone() else {
        st.push_scan_log("No scan report to export yet.");
        return;
    };
    let mut files = vec![report];
    if let Some(j) = &st.scan_json && j.exists() { files.push(j.clone()); }
    let Some(path) = rfd::FileDialog::new().set_file_name("DMZ_SBMM_Reader_results.zip").add_filter("ZIP", &["zip"]).save_file() else {
        st.push_scan_log("ZIP export cancelled.");
        return;
    };
    match crate::zip_export::zip_files(&files, &path) {
        Ok(_) => st.push_scan_log(format!("ZIP written: {}", path.display())),
        Err(e) => st.push_scan_log(format!("ZIP error: {e}")),
    }
}

fn probe_queue_start(st: &mut State) {
    st.ensure_probe();
    if st.probe_done {
        // Re-arm the sampler after a previous "Stop & report".
        st.probe_done = false;
        st.start_net_sampler();
    }
    let result = st.probe_mut(|p| {
        let r = p.mark_queue_start();
        (r, p.match_number)
    });
    let msg = match result {
        Ok((Ok(_), n)) => format!("MATCH {n} queue started"),
        Ok((Err(e), _)) => format!("Probe error: {e}"),
        Err(e) => format!("Probe error: {e}"),
    };
    st.push_probe_log(msg);
    st.update_probe_status();
}

fn probe_queue_end(st: &mut State) {
    st.ensure_probe();
    let result = st.probe_mut(|p| {
        let n = p.match_number;
        (p.mark_queue_end(), n)
    });
    let msg = match result {
        Ok((Ok(sec), n)) => format!("MATCH {n} found ({sec:.1}s)"),
        Ok((Err(e), _)) => e,
        Err(e) => format!("Probe error: {e}"),
    };
    st.push_probe_log(msg);
    st.update_probe_status();
}

fn probe_match_end(st: &mut State) {
    st.ensure_probe();
    let result = st.probe_mut(|p| {
        let n = p.match_number;
        (p.mark_match_end(), n)
    });
    let msg = match result {
        Ok((Ok(_), n)) => format!("MATCH {n} ended"),
        Ok((Err(e), _)) => format!("Probe error: {e}"),
        Err(e) => format!("Probe error: {e}"),
    };
    st.push_probe_log(msg);
    st.update_probe_status();
}

fn probe_stop(st: &mut State) {
    st.ensure_probe();
    if st.probe_done { st.push_probe_log("Probe already stopped."); return; }
    // Stop sampling before writing the report so the CSV is stable.
    st.stop_net_sampler();
    let result = st.probe_ref(|p| p.write_report());
    let msg = match result {
        Ok(Ok(path)) => { st.probe_done = true; format!("Report written: {}", path.display()) }
        Ok(Err(e)) => format!("Report error: {e}"),
        Err(e) => format!("Probe error: {e}"),
    };
    st.push_probe_log(msg);
    st.update_probe_status();
}

fn export_probe_zip(st: &mut State) {
    st.ensure_probe();
    let Some(path) = rfd::FileDialog::new().set_file_name("DMZ_SBMM_Probe_results.zip").add_filter("ZIP", &["zip"]).save_file() else {
        st.push_probe_log("ZIP export cancelled.");
        return;
    };
    let result = st.probe_ref(|p| p.zip_outputs(&path));
    let msg = match result {
        Ok(Ok(_)) => format!("ZIP written: {}", path.display()),
        Ok(Err(e)) => format!("ZIP error: {e}"),
        Err(e) => format!("ZIP error: {e}"),
    };
    st.push_probe_log(msg);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn net_sampler_starts_and_stops() {
        let mut s = State::default();
        assert!(s.probe.is_some());
        assert!(s.net_sampler_thread.is_some(), "sampler thread should be running");
        assert!(s.probe_ref(|p| p.paths.network_csv.exists()).unwrap_or(false));
        s.stop_net_sampler();
        assert!(s.net_sampler_thread.is_none(), "sampler thread should be stopped");
    }
}
