@echo off
cd /d "%~dp0"
start "" "dmz-sbmm-reader.exe"
